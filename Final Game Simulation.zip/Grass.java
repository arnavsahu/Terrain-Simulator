public class Grass extends Terrain{
    //no static methods overridden
}
