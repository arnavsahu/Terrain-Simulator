public class Olivia extends Player{
    public Olivia(){
        super(20.0, 20.0, 20.0);
    }
}
