public class Alexa extends Player{
    public Alexa(){
        super(20.0, 20.0, 20.0);
    }

    public double foodFactor(){
        return 1.2;
    }

    public double waterFactor(){
        return 1.2;
    }

    public double staminaFactor(){
        return 0.2;
    }
}
