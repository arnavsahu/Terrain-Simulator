public class Terrain {
    //these methods are overridden by cast classes i created in the medium and complex brain classes and the player class
    public static double foodCost(){
        return 1.0;
    }
    public static double waterCost(){
        return 1.0;
    }
    public static double staminaCost(){
        return 1.0;
    }
}
